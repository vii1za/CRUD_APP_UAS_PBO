package com.example.crudapp;

public class DBConnection {
}
